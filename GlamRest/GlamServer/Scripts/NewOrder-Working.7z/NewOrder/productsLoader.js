﻿//JS module pattern explained here: http://briancray.com/posts/javascript-module-pattern

function OrderItemViewModel(product) {
    var self = this;

    this.ProductID = "";
    this.Quantity = 0;
    this.DiscountInShekels = 0;
    this.ProductName = "";
    this.Price = "";

    this.updateProduct = function (product) {
        self.ProductID = product.ProductID;
        self.Quantity = 0;
        self.DiscountInShekels = 0;
        self.ProductName = product.ProductName;
        self.Price = product.Price;
    }
}

function productsLoader() {
    // private variables and functions
    var selectorsCounter = 0;
    var selectorWidth = "300px";
    var products;
    var orderItemViewModel = new OrderItemViewModel();

    var itemContainer = null;
    var selector = null;
    var priceLabel = null;
    var quantity = null;
    var totalPriceLabel = null;

    var orderItems = [];

    var loadProducts = function (callback) {
        $.getJSON('api/products', function (items) {
            if (callback) {
                callback(items);
            }
        });
    };
    var onItemChange = function () {
        var chosenProductId = $(this).val();
        var selectedProduct = products[chosenProductId];
        orderItemViewModel.updateProduct(selectedProduct);

        var selectorIdCounter = $(this).attr('id').split('-')[1];
        orderItems[selectorIdCounter] = products[chosenProductId];
        $(this).parent().find(".quantity").first().removeAttr('disabled');
        $(this).parent().find(".quantity").val("");
        $(this).parent().find("#totalPrice-" + selectorIdCounter).val("");
        $(this).parent().find("#price-" + selectorIdCounter).first().val(products[chosenProductId].Price);
    }

    var onQuantityChange = function () {
        var typedAmount = $(this).val();
        var selectorIdCounter = $(this).attr('id').split('-')[1];
        var price = orderItems[selectorIdCounter].Price;

        $(this).parent().find("#totalPrice-" + selectorIdCounter).first().val(typedAmount * price);
    }

    this.createItemsSelector = function () {
        selectorsCounter++;
        orderItems[selectorsCounter] = {};
        itemContainer = document.createElement("div");
        itemContainer.setAttribute("id", "itemContainer-" + selectorsCounter);
        itemContainer.setAttribute("class", "itemContainer");

        selector = document.createElement("select");
        selector.setAttribute("name", "itemSelector-" + selectorsCounter);
        selector.setAttribute("id", "itemSelector-" + selectorsCounter);
        selector.style.width = selectorWidth;

        $(selector).change(onItemChange);

        priceLabel = document.createElement("input");
        priceLabel.setAttribute("id", "price-" + selectorsCounter);
        priceLabel.setAttribute("class", "price");
        priceLabel.setAttribute("type", "text");
        priceLabel.setAttribute("disabled", "disabled");

        quantity = document.createElement("input");
        quantity.setAttribute("type", "text");
        quantity.setAttribute("class", "quantity");
        quantity.setAttribute("id", "quantity-" + selectorsCounter);
        quantity.setAttribute("disabled", "disabled");
        $(quantity).ForceNumericOnly();
        $(quantity).keyup(onQuantityChange);

        totalPriceLabel = document.createElement("input");
        totalPriceLabel.setAttribute("id", "totalPrice-" + selectorsCounter);
        priceLabel.setAttribute("class", "price");
        totalPriceLabel.setAttribute("type", "text");
        totalPriceLabel.setAttribute("disabled", "disabled");

        if (products) {
            loadProductsToSelector(selector);
        } else {
            loadProducts(function (items) {
                products = createProductsHashById(items);
                loadProductsToSelector(selector);
            });
        }

        itemContainer.appendChild(selector);
        itemContainer.appendChild(priceLabel);
        itemContainer.appendChild(quantity);
        itemContainer.appendChild(totalPriceLabel);

        return itemContainer;
    };

    var createProductsHashById = function (items) {
        var hashedProducts = [];
        for (var i in items) {
            hashedProducts[items[i].ProductID] = items[i];
        }
        return hashedProducts;
    };

    var loadProductsToSelector = function (selector) {
        for (var i in products) {
            selector.add(new Option(products[i].ProductID + " - " + products[i].ProductName, products[i].ProductID));
        }
    };
};