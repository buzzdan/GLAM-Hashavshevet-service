﻿var newOrderPage = (function () {
    // private variables and functions
    var counter = 0;
    var itemsLoaders = [];

    // constructor
    var newOrderPage = function () {
    };

    var addItem = function () {
        counter++;
        itemsLoaders[counter] = new productsLoader();
        var newItem = itemsLoaders[counter].createItemsSelector();
        $("#itemsContainer").append(newItem);
        $(newItem).find("select").first().select2();
    };

    var loadClients = function (selectElement, callback) {
        $.getJSON('api/clients', function (items) {
            for (var i in items) {
                selectElement.add(new Option(items[i].ClientID + " - " + items[i].ClientName, items[i].ClientID));
            }

            if (callback)
                callback();
        });
    };

    var createClientsSelector = function (callback) {
        var selector = document.createElement("select");
        selector.setAttribute("name", "clientsPicker");
        selector.setAttribute("id", "clientsPicker");
        selector.style.width = "300px";

        loadClients(selector, callback);

        return selector;
    };

    var initClients = function () {
        var container = document.getElementById("clientsPickerContainer");
        container.innerText = "Loading...";
        var clientsSelector = createClientsSelector(function () {
            container.innerText = "";
            document.getElementById("clientsPickerContainer").appendChild(clientsSelector);
            $("#clientsPicker").select2({});
        });
    };

    var init = function () {
        initClients();

        //first item
        addItem();

        $("#AddItemButton").click(function () {
            addItem();
        });
    };

    // prototype
    newOrderPage.prototype = {
        constructor: newOrderPage,
        init: init
    };

    // return productsLoader
    return newOrderPage;
})();

//var newOrderPage = (function () {
//    // private variables and functions
//    var itemsLoader;

//    // constructor
//    var newOrderPage = function () {
//        itemsLoader = new productsLoader();
//    };

//    var init = function () { alert("hi"); };
//    // prototype
//    newOrderPage.prototype = {
//        constructor: newOrderPage,
//        init: init
//    };

//    // return module
//    return newOrderPage;
//})();